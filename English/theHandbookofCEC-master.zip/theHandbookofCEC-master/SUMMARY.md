# Summary

- [致辞](README.md)
- [为什么开设认知英语课？](Why.md)
- [什么是认知英语课？](What.md)
- [如何学习认知英语课？](How.md)
- [认知英语模型](Model.md)
- [如何规划个人英语学习路径](Plan.md)